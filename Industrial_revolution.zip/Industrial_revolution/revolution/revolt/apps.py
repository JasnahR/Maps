from django.apps import AppConfig


class RevoltConfig(AppConfig):
    name = 'revolt'
